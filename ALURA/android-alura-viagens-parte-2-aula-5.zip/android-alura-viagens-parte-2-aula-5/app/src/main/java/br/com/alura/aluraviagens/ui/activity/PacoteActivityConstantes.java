package br.com.alura.aluraviagens.ui.activity;

public interface PacoteActivityConstantes {
    String CHAVE_PACOTE = "pacote";
}
