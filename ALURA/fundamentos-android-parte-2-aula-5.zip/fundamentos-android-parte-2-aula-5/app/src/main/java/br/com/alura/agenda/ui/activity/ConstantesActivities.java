package br.com.alura.agenda.ui.activity;

public interface ConstantesActivities {
    String CHAVE_ALUNO = "aluno";
}
