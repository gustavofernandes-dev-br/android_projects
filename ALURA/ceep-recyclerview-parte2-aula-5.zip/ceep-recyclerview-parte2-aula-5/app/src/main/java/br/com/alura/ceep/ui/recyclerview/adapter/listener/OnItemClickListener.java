package br.com.alura.ceep.ui.recyclerview.adapter.listener;

import br.com.alura.ceep.model.Nota;

public interface OnItemClickListener {

    void onItemClick(Nota nota, int posicao);
}
