# Formulário em Flutter

Projeto de exemplo para o [artigo de criação de formulário em Flutter](https://www.alura.com.br/artigos/criando-formulario-com-flutter).