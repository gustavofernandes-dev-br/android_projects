package com.example.launcher

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
